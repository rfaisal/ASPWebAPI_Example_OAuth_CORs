﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Skeleton.WebAPI.Models
{
    public class Greeting
    {
        public int id { get; set; }
        public string content { get; set; }
    }
}